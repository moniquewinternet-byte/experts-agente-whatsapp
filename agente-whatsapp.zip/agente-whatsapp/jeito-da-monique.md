# O jeito da Monique organizar o WhatsApp

É assim que o robô dela funciona hoje. Os nomes pessoais foram trocados por exemplos.
O arquivo pronto pra usar é o `robo/regras-exemplo-da-monique.json`.

## O que ela arquiva
- Todos os GRUPOS de curso, mentoria, comunidade e avisos (menos os protegidos).
- Conversas em que a última coisa foi uma REAÇÃO (dela ou da outra pessoa): assunto encerrado.
- MARCAS e empresas (iFood, Mercado Livre, Shopee, companhia aérea, banco digital...).
- SPAM DE NÚMERO: mensagem de código, pedido, entrega, rastreio, fatura e nota fiscal, vinda de
  número sem nome salvo. Pessoa com nome salvo nunca entra por aqui.

## O que ela protege (nunca arquiva)
- Conversas FIXADAS.
- Família, consultoria, clínicas e saúde, contador.
- Grupos de trabalho que ela usa todo dia.
- Quem ela está ESPERANDO responder (ela coloca o nome na lista enquanto espera e tira depois).

## O que fica na tela
- Mensagem de pessoa de verdade que ela ainda não leu (o número verde). Primeiro ela lê.

## O que ela aprendeu usando
- "Eu mandei por último" parece conversa resolvida, mas muitas vezes é "estou esperando a resposta".
  Por isso essa categoria vem como REVISAR: o robô lista e ela decide uma a uma.
- Número sem nome: ela não consegue julgar só pelo número. Antes de arquivar, olha a prévia.
- Conversa de número não salvo e alguns canais de aviso às vezes não arquivam pelo robô. Esses ela
  arquiva na mão, pela busca, e é rápido.
- Uma janela por vez: ou ela mexe no WhatsApp Web do robô, ou o robô roda. Os dois juntos brigam.
- Ritmo: de 4 a 9 segundos entre cada conversa, e uma pausa maior de vez em quando. O modo bem lento
  (cauteloso) ela usa só no começo; depois achou arrastado.
- No Windows, o navegador que funciona melhor pro robô é o Edge, que já vem instalado.
