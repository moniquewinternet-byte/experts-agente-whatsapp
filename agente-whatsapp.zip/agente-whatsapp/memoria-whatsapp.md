# O que o agente aprendeu sobre este WhatsApp

Atualizado a cada uso. Guarda só REGRAS e o perfil, nunca o conteúdo das conversas.

## Perfil (a Entrevistadora preenche na primeira vez)
- O que a pessoa quer resolver:
- WhatsApp pessoal, Business ou os dois:
- Usa o mesmo número pra vida pessoal e pro negócio:
- Ferramentas que já usa (CRM, checkout, ManyChat, n8n...):
- Computador (Windows ou Mac):
- Caminho escolhido:

## Regras do robô (confirmadas por ela)
- Protegidos:
- Marcas:
- O que arquiva:

## Observações (ainda não são regra)
Uma correção de um caso só fica aqui. Vira regra quando ela confirmar ou quando o padrão repetir.

## Tom dela pra responder (a Redatora lê do segundo cérebro e resume aqui)
- De onde veio (nota do cofre):
- Como cumprimenta:
- Como fecha:
- Palavras e marcadores que ela usa:
- O que ela nunca escreve:
