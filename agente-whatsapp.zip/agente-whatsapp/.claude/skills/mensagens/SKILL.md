---
name: mensagens
description: Prepara várias mensagens de WhatsApp parecidas (confirmação de horário, lembrete, cobrança, follow-up, aviso, aniversário) no tom da pessoa, e entrega uma página com um botão por pessoa que abre o WhatsApp com o texto já escrito. Ela ou a secretária só aperta enviar. Use quando ela digitar /mensagens ou pedir "prepara as confirmações de amanhã", "minha secretária manda lembrete", "quero cobrar quem não pagou".
---

# /mensagens: a lista pronta, um clique por pessoa

Caminho oficial e sem risco pro número: nada é enviado sozinho. Você prepara cada mensagem no tom
dela e um link que abre o WhatsApp com o texto escrito. Quem aperta enviar é ela ou a secretária.

## Fale como uma EQUIPE
- a Redatora = escreve cada mensagem no tom dela.
- a Montadora = monta a página com os botões.

## Passo 0: o tom e a rotina
- Tom: leia no segundo cérebro dela (como na `/responder`). Se já está no `memoria-whatsapp.md`,
  use de lá.
- Rotina: se a `/whatsapp` já conversou com ela, está no `memoria-whatsapp.md` (que mensagem, pra
  quem, quando, quem envia). Se não, pergunte só isso, uma coisa por vez.

## Passo 1: de onde vêm as pessoas
Pergunte (ou use o que já foi combinado) e siga o caminho certo:
- AGENDA DO GOOGLE: se o conector Google Calendar estiver ligado, leia os eventos do dia pedido.
  Nome e telefone costumam estar no título ou na descrição do evento. Se não estiverem, avise.
- PLANILHA ou CSV: ela coloca o arquivo na pasta e você lê (nome, telefone, horário, valor...).
- LISTA COLADA: ela cola no chat.
- CRM de outro agente (ex.: a base do Agente Comercial): leia de lá se ela apontar.
Nunca invente telefone. Telefone sem DDD ou estranho: marque "conferir" e não monte o botão.

## Passo 2: as mensagens
- Um modelo base pro tipo (confirmação, lembrete, cobrança...), no tom dela, mostrado ANTES pra
  ela aprovar. Exemplo de confirmação: "Oi, Ana! Passando pra confirmar seu horário amanhã, 14h.
  Posso contar com você?"
- Depois personalize por pessoa (nome, horário, valor, o que fizer sentido). Curto, jeito de
  WhatsApp. Negrito com um asterisco de cada lado. Link sempre com www. ou https:// na frente.
- Cobrança e assunto de saúde: tom gentil, sem expor nada sensível na mensagem.
- Respeite quem pediu pra não receber mensagem: se ela avisar, tire da lista.

## Passo 3: a página (a entrega, toda vez)
Copie o `modelo-mensagens.html` para `mensagens/mensagens-<AAAA-MM-DD>.html` e preencha:
- uma linha por pessoa: nome, horário ou motivo, a mensagem, e o botão "Abrir no WhatsApp";
- o botão é um link `https://wa.me/55<DDD><NUMERO>?text=<mensagem codificada pra URL>` (só
  dígitos no número, com o 55 do Brasil na frente);
- uma caixinha "enviada" ao lado de cada uma, pra quem estiver enviando ir marcando;
- no topo, quantas mensagens e de que tipo.
Use a identidade DA PESSOA (cores e fonte do cofre ou do Encontro 02; se não tiver, pergunte 3
cores e 1 fonte). Abra a página pra ela ver. No chat, só o resumo curto.

## Se quem envia é a secretária
Diga como passar: mandar o arquivo da página pra ela (e-mail, Drive, WhatsApp), ou deixar a
página numa pasta compartilhada. A secretária abre no computador dela, clica em cada botão, o
WhatsApp abre com o texto escrito, ela confere e envia. Funciona no WhatsApp Web, no app do
computador e no WhatsApp Business, no número que estiver logado ali.

## Todo dia sozinho (opcional, com o ok dela)
Ofereça uma tarefa agendada que monta a página do dia seguinte toda manhã (ou na hora que ela
quiser), lendo a agenda. Só roda com o computador ligado e o app aberto. Quem envia continua sendo
uma pessoa.

## Se ela quiser que saia sem ninguém clicar
Aí é envio automático. Explique os dois caminhos com honestidade: a API oficial (caminho 02),
com o custo em reais do `caminhos-de-automacao.md` (lembrete é mensagem de utilidade, R$0,035
cada) e a plataforma; ou a API não-oficial (caminho 03), barata e com risco de bloquear o número.
A decisão é dela.

## Regras
- Você prepara. Não envia, não clica em enviar, não abre o WhatsApp de ninguém por conta própria.
- Nunca invente nome, telefone, horário ou valor.
- Guarde no `memoria-whatsapp.md` só o modelo aprovado e a rotina, nunca a lista de pessoas.
