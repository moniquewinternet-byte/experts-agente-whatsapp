---
name: mensagens
description: Prepara várias mensagens de WhatsApp parecidas (confirmação de horário, lembrete, cobrança, follow-up, aviso, aniversário) no tom da pessoa, e entrega uma página com um botão por pessoa que abre o WhatsApp com o texto já escrito. Ela ou a secretária só aperta enviar. Use quando ela digitar /mensagens ou pedir "prepara as confirmações de amanhã", "minha secretária manda lembrete", "quero cobrar quem não pagou".
---

# /mensagens: a lista pronta, um clique por pessoa

Caminho oficial e sem risco pro número: nada é enviado sozinho. Você prepara cada mensagem no tom
dela e um link que abre o WhatsApp com o texto escrito. Quem aperta enviar é ela ou a secretária.

## Fale como uma EQUIPE
- a Redatora = escreve cada mensagem no tom dela.
- a Montadora = monta a página com os botões.

## Passo 0: o tom e a rotina (PARADA 1: o tom)
- Tom: leia no segundo cérebro dela (como na `/responder`). Se já está no `memoria-whatsapp.md`,
  use de lá. Mostre o que entendeu do tom e espere o ok dela antes de seguir.
- Rotina: se a `/whatsapp` já conversou com ela, está no `memoria-whatsapp.md` (que mensagem, pra
  quem, quando, quem envia). Se não, pergunte só isso, uma coisa por vez.
- Em nome de quem a mensagem sai? Da dona ("Oie, aqui é a Vivi") ou da secretária ("Oi, aqui é a
  Ana, do consultório da Vivi")? Pergunte se não estiver na memória.
- Mensagem pra quem já é cliente ou tem horário marcado não é disparo em massa: cumprimentar pelo
  nome, no tom dela, é o certo.

## Passo 1: de onde vêm as pessoas
Pergunte (ou use o que já foi combinado) e siga o caminho certo:
- AGENDA DO GOOGLE: se o conector Google Calendar estiver ligado, leia os eventos do dia pedido.
  Se não estiver: "No app do Claude, vá em Configurações > Conectores e ligue o Google Calendar.
  Se preferir não ligar agora, me cola a agenda de amanhã." Nome e telefone nem sempre estão no
  evento: se faltar telefone, peça a lista de contatos (planilha) ou marque "conferir".
- PLANILHA (.xlsx do Excel) ou CSV: ela coloca o arquivo na pasta e você lê. Excel você lê direto
  (com Python, se precisar); confira com ela qual ABA usar. Se ela preferir mandar CSV, peça
  "Salvar como > CSV UTF-8". Trate telefone como texto: se aparecer algo como "1,19889E+10", o
  Excel estragou o número; peça pra ela formatar a coluna como texto e salvar de novo.
- LISTA COLADA: ela cola no chat.
- CRM de outro agente (ex.: a base do Agente Comercial): leia de lá se ela apontar.
Nunca invente telefone. Como tratar cada telefone:
1. Tire tudo que não é número (espaço, traço, parênteses, +).
2. Se começa com 55 e tem 12 ou 13 dígitos, tire o 55 do começo (ele volta no link).
3. Sobrou 10 ou 11 dígitos (DDD + número)? Válido. O link é `https://wa.me/55` + esses dígitos.
4. Qualquer outro tamanho (sem DDD, faltando número): marque "conferir o telefone" e não monte o
   botão. A linha da pessoa continua na página, com a mensagem.

## Passo 2: as mensagens (PARADA 2: o modelo)
- Um modelo base pro tipo (confirmação, lembrete, cobrança...), no tom dela, mostrado ANTES pra
  ela aprovar. Só depois do ok você personaliza. Exemplo de confirmação: "Oi, Ana! Passando pra confirmar seu horário amanhã, 14h.
  Posso contar com você?"
- Depois personalize por pessoa (nome, horário, valor, o que fizer sentido).
- Cliente que é EMPRESA: o "Oi" vai pro CONTATO (a pessoa), e a empresa aparece na mensagem e na
  página ("Oi, Carlos! Lembrete dos documentos da Padaria Sol..."). Se o mesmo telefone aparece em
  mais de uma empresa (um dono com dois CNPJs), junte numa mensagem só, citando as empresas. Curto, jeito de
  WhatsApp. Negrito com um asterisco de cada lado.
- Link: o WhatsApp só deixa clicar se tiver www. ou https:// na frente. Use https:// quando o
  endereço tiver algo antes do domínio (ex.: https://claude.site.com.br), porque www. na frente
  de um endereço assim pode não abrir. Use www. só quando o próprio endereço já é www.site.com.br.
- Cobrança e assunto de saúde: tom gentil, sem expor nada sensível na mensagem (nada de tipo de
  consulta, exame, diagnóstico ou valor devido em detalhe).
- Respeite quem pediu pra não receber mensagem: se ela avisar, tire da lista.

## Passo 3: a página (a entrega, toda vez)
Copie o `modelo-mensagens.html` para `mensagens/mensagens-<AAAA-MM-DD>.html`, com a data do DIA
DO ENVIO (não a do atendimento), e preencha:
- uma linha por pessoa: nome, horário ou motivo, a mensagem, e o botão "Abrir no WhatsApp";
- o botão é um link `https://wa.me/55<DDD><NUMERO>?text=<mensagem codificada pra URL>` (só
  dígitos no número, com o 55 do Brasil na frente);
- uma caixinha "enviada" ao lado de cada uma, pra quem estiver enviando ir marcando;
- no topo: "Pra enviar em [dia do envio]", o tipo e a que se referem ("atendimentos de 25/11"),
  quantas estão prontas e quantas estão pra conferir;
- a fonte dela pelo link do Google Fonts no `<head>` (o modelo mostra onde), senão ela não aparece;
- texto do botão: se a cor de destaque dela for clara (amarelo, laranja claro), use texto escuro
  no botão (`--texto-botao`), pra dar pra ler.
Use a identidade DA PESSOA (cores e fonte do cofre ou do Encontro 02; se não tiver, pergunte 3
cores e 1 fonte). Abra a página pra ela ver. No chat, só o resumo curto.

## Arquivo junto (guia, boleto, contrato, material)
O link do WhatsApp abre a conversa só com o TEXTO: ele não anexa arquivo. Diga isso com clareza.
Na linha da pessoa, escreva "anexar: [nome do arquivo]" (ex.: "guia-DAS-padaria-sol.pdf") e, se
ela tiver uma pasta com os arquivos, procure o arquivo de cada um e mostre o nome certo. Quem
envia abre a conversa pelo botão, anexa o arquivo e envia. Se isso for todo mês e em volume, mostre
o caminho 02 (API oficial), que manda mensagem com documento, e o custo.
Valor e data de vencimento: só entram na mensagem se estiverem na planilha. Nunca invente.

## Muitas mensagens no mesmo dia
Até umas 30, uma página só. Mais que isso, sugira dividir em lotes (por dia de vencimento, por
letra, por responsável) pra não virar uma tarde inteira clicando, e mostre a conta do caminho 02
(R$0,035 por mensagem de utilidade, mais a plataforma). A página guarda o que já foi marcado como
enviado, mesmo se fechar e abrir de novo no mesmo computador.

## Segunda rodada (cobrar quem não mandou)
Sugira uma coluna de status na planilha ("documentos recebidos: sim/não"). Na segunda rodada,
monte a página só com quem está "não", com uma mensagem de lembrete gentil.

## Sigilo (sempre, e mais ainda em saúde, terapia, contabilidade, advocacia)
A página tem nome e telefone de clientes, às vezes valor e dado fiscal. Ela fica no computador
dela. Se outra pessoa vai enviar, passe por uma pasta compartilhada só entre as duas (Drive ou
OneDrive com acesso restrito), nunca pelo próprio WhatsApp ou e-mail aberto. Apague as páginas
antigas de tempos em tempos (ofereça fazer isso). Valor, CNPJ e dado fiscal só em mensagem
individual, e só depois de conferir que o telefone é daquele cliente (telefone desatualizado manda
o dado pra outra pessoa). Se ela for de área com sigilo profissional (psicologia, medicina,
contabilidade, direito), lembre disso uma vez, sem assustar, e siga as regras do conselho dela.

## Se quem envia é a secretária
Diga como passar: deixar a página numa pasta compartilhada só entre as duas (veja Sigilo). A secretária abre no computador dela, clica em cada botão, o
WhatsApp abre com o texto escrito, ela confere e envia. Funciona no WhatsApp Web, no app do
computador e no WhatsApp Business, no número que estiver logado ali.

## Todo dia sozinho (opcional, com o ok dela)
Ofereça uma tarefa agendada que monta a página do dia seguinte toda manhã (ou na hora que ela
quiser), lendo a agenda. Só roda com o computador ligado e o app aberto. Quem envia continua sendo
uma pessoa.

## Se ela quiser que saia sem ninguém clicar
Aí é envio automático. Explique os dois caminhos com honestidade: a API oficial (caminho 02),
com o custo em reais do `caminhos-de-automacao.md` (lembrete é mensagem de utilidade, R$0,035
cada) e a plataforma; ou a API não-oficial (caminho 03), barata e com risco de bloquear o número.
A decisão é dela.

## Regras
- Você prepara. Não envia, não clica em enviar, não abre o WhatsApp de ninguém por conta própria.
- Nunca invente nome, telefone, horário ou valor.
- Guarde no `memoria-whatsapp.md` só o modelo aprovado e a rotina, nunca a lista de pessoas.
