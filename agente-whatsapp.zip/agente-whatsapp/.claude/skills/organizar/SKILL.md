---
name: organizar
description: Monta e roda o robô que organiza o WhatsApp Web da pessoa (só arquiva), do jeito da Monique ou adaptado pra ela. Faz o login, simula, mostra a lista e só arquiva com o ok. Use quando ela digitar /organizar ou pedir "organiza meu WhatsApp", "arquiva meus grupos", "limpa meu WhatsApp".
---

# /organizar: o robô que deixa o WhatsApp limpo

O robô está na pasta `robo/`. Ele SÓ ARQUIVA (arquivar se desfaz). Nunca apaga, nunca manda
mensagem, nunca sai de grupo.

## Fale como uma EQUIPE
- a Montadora = monta as regras e instala (Passos 1 a 3).
- a Faxineira = simula e arquiva (Passos 4 e 5).

## Primeiro contato (só na primeira vez)
Diga em poucas linhas, antes de instalar qualquer coisa:
"Esse robô abre o seu WhatsApp Web e arquiva conversa, igual você faria clicando. Ele não apaga e
não manda nada. Ele é um caminho não-oficial, então anda devagar, como uma pessoa, e sempre mostra
antes o que vai fazer. Você decide o que ele arquiva."

## Passo 1: igual à Monique ou do seu jeito?
Mostre o `jeito-da-monique.md` em resumo e pergunte:
"Quer fazer igual a Monique e só trocar os nomes protegidos pelos seus, ou quer montar do seu jeito?"
- IGUAL: copie `robo/regras-exemplo-da-monique.json` para `robo/regras.json` e vá pro Passo 2 só
  pra trocar os protegidos.
- DO SEU JEITO: faça as perguntas do Passo 2 e monte o `robo/regras.json` do zero.

## Passo 2: as regras dela (a Montadora pergunta)
Uma pergunta por vez:
0. Antes de perguntar, olhe o segundo cérebro dela (Projetos e Sobre mim): clientes, sócios,
   família e grupos de trabalho que aparecem lá viram SUGESTÃO de protegidos. Mostre a lista e
   peça o ok, nunca proteja nem deixe de proteger por conta própria.
1. Quais conversas e grupos NUNCA podem sumir da sua tela? (família, clientes, trabalho, saúde,
   escola dos filhos...). Viram `protegidos` (basta um pedaço do nome).
2. Seus grupos: pode arquivar todos, menos esses protegidos?
3. Quando a última coisa da conversa foi uma reação, já pode arquivar?
4. E quando foi você que mandou a última mensagem? Arquivo direto, ou te mostro pra você decidir uma
   a uma? (Conte o que a Monique aprendeu: muitas vezes é "estou esperando resposta". O padrão é
   "revisar".)
5. Quais empresas te mandam mensagem e podem sair da frente? Viram `marcas`.
6. Mensagem de código, pedido, entrega e fatura vinda de número sem nome: pode arquivar?
Mostre o `regras.json` pronto em linguagem simples ("vou proteger: ...; vou arquivar: ...") e
peça o ok. Salve as regras confirmadas no `memoria-whatsapp.md`.

## Passo 3: instalar
- Confira se o Node.js está instalado (`node -v`). Se não estiver, passe o link nodejs.org (LTS) e
  espere ela instalar.
- Dentro de `robo/`: `npm install`.
- O robô usa o Edge no Windows e o Chrome no Mac. Se nenhum abrir, rode `npx playwright install
  chromium` e tente de novo.

### IMPORTANTE: login, simular e rodar demoram mais que 2 minutos
O simular leva uns 4 a 5 minutos (o WhatsApp Web carrega antes de ler). Um comando seu que passa de
2 minutos é cortado no meio. Então NUNCA rode login, simular ou rodar como comando normal:
- WINDOWS (o jeito mais fácil): peça pra ELA dar dois cliques no atalho da pasta `robo/`
  (`1-LOGIN`, `2-SIMULAR`, `3-RODAR`). Abre uma janela preta própria, sem limite de tempo. Diga
  "quando aparecer 'Pressione qualquer tecla', me avisa". Aí você lê o log em `robo/logs/`.
- MAC, ou se ela preferir que você rode: rode o comando EM SEGUNDO PLANO (background) ou com tempo
  limite de 10 minutos, e espere terminar antes de ler o log.
Comando rápido (`node -v`, `npm install`, ler log) pode rodar normal.

- Login: atalho `1-LOGIN` (ou `node organizar-whatsapp.js login` em segundo plano). Uma janela do
  navegador abre com o QR. Diga: "Agora é com você: no celular, WhatsApp > Aparelhos conectados >
  Conectar aparelho, e escaneia o QR." Você nunca faz essa parte. O login fica salvo na pasta
  `robo/perfil`.
- Avise antes: "O WhatsApp Web demora pra carregar na primeira vez. É normal. O robô espera
  carregar tudo antes de ler, senão ele lê errado."

## Passo 4: simular (sempre antes de arquivar)
Atalho `2-SIMULAR` (ou `node organizar-whatsapp.js simular` em segundo plano). Nada é arquivado.
Quando terminar, leia o log mais novo em
`robo/logs/` e mostre pra ela, agrupado:
- quantos grupos, reações, marcas e spam ele arquivaria (com os nomes);
- os protegidos que ele pulou;
- a lista de REVISAR (você mandou por último), pra ela marcar quais podem ir.
Pergunte: "Tem alguma aqui que não pode sair da tela?" Se tiver, ajuste o `regras.json` e simule de
novo. Mudou regra, simula de novo. Sempre.

## Passo 5: arquivar (só com o "pode" dela)
- Primeira vez: sugira um limite pequeno pra ela ver funcionando (`"limite_por_rodada": 15`).
- Atalho `3-RODAR` (ou `node organizar-whatsapp.js rodar` em segundo plano). Ele anda devagar de propósito (de 4 a 9 segundos por
  conversa e uma pausa maior de vez em quando). Não acelere.
- No fim, mostre o resumo do log: quanto arquivou de cada tipo e o que falhou.
- O que falhou (número não salvo, alguns canais) ela arquiva na mão pela busca. Não insista no robô.
- Conversas da lista REVISAR que ela aprovou: coloque o nome delas numa rodada própria ou oriente a
  arquivar na mão. Nunca arquive "revisar" sem o ok.

## Regras de uso que você explica
- Uma janela por vez: enquanto o robô roda, ela não mexe naquela janela. Pra mexer na mão, use
  `node organizar-whatsapp.js abrir` (atalho `4-ABRIR`) e feche a janela quando terminar.
- Pra pausar tudo: criar um arquivo `PAUSADO.txt` dentro de `robo/`.
- Grupo muito ativo volta pra tela quando chega mensagem nova. Isso é do WhatsApp, não é erro.
- Rodar todo dia sozinho (tarefa agendada) é possível, mas só depois de ela ter rodado algumas vezes
  com você e confiar no resultado. Ofereça, não faça por conta.

## No fim: aprenda (com TRAVA)
Pergunte se acertou. Uma correção de um caso vira OBSERVAÇÃO no `memoria-whatsapp.md`. Só vira
regra no `regras.json` quando ela confirmar ou quando o padrão repetir.
