---
name: organizar
description: Monta e roda o robô que organiza o WhatsApp Web da pessoa (só arquiva), com as regras que ELA escolhe (o jeito da Monique serve de exemplo). Faz o login, simula, mostra a lista e só arquiva com o ok. Use quando ela digitar /organizar ou pedir "organiza meu WhatsApp", "arquiva meus grupos", "limpa meu WhatsApp".
---

# /organizar: o robô que deixa o WhatsApp limpo

O robô está na pasta `robo/`. Ele SÓ ARQUIVA (arquivar se desfaz). Nunca apaga, nunca manda
mensagem, nunca sai de grupo.

## Fale como uma EQUIPE
- a Montadora = monta as regras e instala (Passos 1 a 3).
- a Faxineira = simula e arquiva (Passos 4 e 5).

## Primeiro contato (só na primeira vez)
Diga em poucas linhas, antes de instalar qualquer coisa:
"Esse robô abre o seu WhatsApp Web e arquiva conversa, igual você faria clicando. Ele não apaga e
não manda nada. Ele é um caminho não-oficial, então anda devagar, como uma pessoa, e sempre mostra
antes o que vai fazer. Você decide o que ele arquiva."

## Passo 1: o que ELA quer (a Montadora pergunta, ela decide)
As regras são DELA. Comece pela vontade dela, não por um modelo pronto.
Primeiro olhe o segundo cérebro dela (Projetos e a pasta de quem ela é): clientes, sócios,
família e grupos de trabalho que aparecem lá viram SUGESTÃO, que você mostra e ela confirma.
Depois abra com uma pergunta aberta, nas palavras dela:
"Quando você abre o seu WhatsApp, o que você queria que não estivesse ali? E o que nunca pode
sumir da sua tela?"
Escute e anote. Se ela não souber por onde começar, aí sim mostre o `jeito-da-monique.md` como
EXEMPLO ("a Monique arquiva isso e protege aquilo; alguma dessas serve pra você?"). Nunca copie as
regras da Monique sem ela escolher uma por uma.

## Passo 2: completar as regras (uma pergunta por vez, só o que ela ainda não respondeu)
1. O que NUNCA pode sumir? (família, clientes, trabalho, saúde, escola dos filhos...). Viram
   `protegidos` (basta um pedaço do nome).
2. GRUPOS (pergunte SEMPRE): "Você tem grupos de trabalho em andamento, como obra, turma, projeto,
   cliente? Como eu sei quais estão ativos e quais já acabaram?" Conforme a resposta:
   - Poucos grupos de trabalho, com nome fácil: proteja pelo pedaço do nome e deixe `"grupos": true`.
   - Muitos grupos de trabalho, ou nomes sem padrão (ex.: "Casarão Rua X", "Restauro Igreja"):
     `"grupos": "revisar"`. O robô só LISTA os grupos; ela escolhe os que acabaram e você coloca
     esses nomes em `"arquivar_estes_nomes"`. Nada de grupo some sem ela escolher.
   - Ela não quer que mexa em grupo nenhum: `"grupos": false`.
   Grupo com mensagem NÃO LIDA nunca é arquivado (`"grupo_com_nao_lida": false`), pra pedido de
   cliente e foto de obra não sumirem. Só mude isso se ela pedir.
   Avise: grupo novo de trabalho (obra nova, turma nova) precisa entrar nos protegidos antes da
   próxima rodada, se ela estiver usando `"grupos": true`.
3. Quando a última coisa da conversa foi uma reação, já pode arquivar?
4. E quando foi você que mandou a última mensagem? Arquivo direto, ou te mostro pra você decidir uma
   a uma? (Pode contar o que a Monique aprendeu: muitas vezes é "estou esperando resposta". Se ela
   não tiver certeza, o padrão é "revisar".)
5. Quais empresas te mandam mensagem e podem sair da frente? Viram `marcas`.
6. Mensagem de código, pedido, entrega e fatura vinda de número sem nome: pode arquivar?
Monte o `robo/regras.json` com as respostas dela (use o `robo/regras-exemplo-da-monique.json` só
como molde do FORMATO do arquivo, não do conteúdo). Mostre as regras em linguagem simples ("vou
proteger: ...; vou arquivar: ...; vou te mostrar pra decidir: ...") e peça o ok. Salve as regras
confirmadas no `memoria-whatsapp.md`.

## Passo 3: instalar
- Confira se o Node.js está instalado (`node -v`). Se não estiver, passe o link nodejs.org (LTS) e
  espere ela instalar.
- Dentro de `robo/`: `npm install`.
- O robô usa o Edge no Windows e o Chrome no Mac. No Mac, ANTES do login, confira se o Chrome existe
  (`ls "/Applications/Google Chrome.app"`). Se não existir, rode `npx playwright install chromium`
  dentro de `robo/` (é um download, pode rodar normal) e só depois siga.
- O robô lê o WhatsApp Web em português (e entende inglês). Se ela usa o WhatsApp em outro idioma,
  avise que o robô pode não achar os botões.
- MAC: se a pasta do agente estiver no iCloud (Mesa ou Documentos sincronizados), sugira mover pra
  uma pasta fora da nuvem (ex.: a pasta do usuário), porque o login do WhatsApp fica salvo em
  `robo/perfil` e a nuvem pode estragar. Depois de instalar o Node no Mac, pode ser preciso fechar e
  abrir o Claude de novo pro `node -v` funcionar. O Mac pode pedir permissão pro app acessar a pasta
  Documentos ou Mesa: é só permitir.

### IMPORTANTE: login, simular e rodar demoram mais que 2 minutos
O simular leva uns 4 a 5 minutos (o WhatsApp Web carrega antes de ler). Um comando seu que passa de
2 minutos é cortado no meio. Então NUNCA rode login, simular ou rodar como comando normal:
- WINDOWS (o jeito mais fácil): peça pra ELA dar dois cliques no atalho da pasta `robo/`
  (`1-LOGIN`, `2-SIMULAR`, `3-RODAR`). Abre uma janela preta própria, sem limite de tempo. Diga
  "quando aparecer 'Pressione qualquer tecla', me avisa". Aí você lê o log em `robo/logs/`.
- MAC (não tem os atalhos), ou se ela preferir que você rode: rode SEMPRE EM SEGUNDO PLANO
  (background), de dentro da pasta `robo/` (`cd robo` antes, com aspas se o caminho tiver espaço),
  e espere terminar antes de ler o log. Nunca use tempo limite: o `rodar` pode passar de 10 minutos.
  O log é gravado linha a linha em `robo/logs/`, então dá pra acompanhar enquanto roda.
- Avise: abre uma janela do navegador com uma faixa dizendo que está sendo controlado por software
  automatizado. É o robô. Ela não fecha nem mexe nessa janela enquanto ele trabalha.
Comando rápido (`node -v`, `npm install`, ler log) pode rodar normal.

- Login: atalho `1-LOGIN` (ou `node organizar-whatsapp.js login` em segundo plano). Uma janela do
  navegador abre com o QR. Diga: "Agora é com você: no celular, WhatsApp > Aparelhos conectados >
  Conectar aparelho, e escaneia o QR." Você nunca faz essa parte. O login fica salvo na pasta
  `robo/perfil`.
- Avise antes: "O WhatsApp Web demora pra carregar na primeira vez. É normal. O robô espera
  carregar tudo antes de ler, senão ele lê errado."

## Passo 4: simular (sempre antes de arquivar)
Atalho `2-SIMULAR` (ou `node organizar-whatsapp.js simular` em segundo plano). Nada é arquivado.
Quando terminar, leia o log mais novo em
`robo/logs/` e mostre pra ela, agrupado:
- quantos grupos, reações, marcas e spam ele arquivaria (com os nomes);
- os protegidos que ele pulou;
- a lista de REVISAR (você mandou por último, e os grupos, se estiver em "revisar"), pra ela
  marcar quais podem ir.
- se o log disser que não achou o filtro "Grupos", avise: nesta rodada ele não mexeu em grupo.
Pergunte: "Tem alguma aqui que não pode sair da tela?" Se tiver, ajuste o `regras.json` e simule de
novo. Mudou regra, simula de novo. Sempre.

## Passo 5: arquivar (só com o "pode" dela)
- Primeira vez: sugira um limite pequeno pra ela ver funcionando (`"limite_por_rodada": 15`).
- Atalho `3-RODAR` (ou `node organizar-whatsapp.js rodar` em segundo plano). Ele anda devagar de propósito (de 4 a 9 segundos por
  conversa e uma pausa maior de vez em quando). Não acelere.
- No fim, mostre o resumo do log: quanto arquivou de cada tipo e o que falhou.
- O que falhou (número não salvo, alguns canais) ela arquiva na mão pela busca. Não insista no robô.
- Conversas e grupos da lista REVISAR que ela aprovou: coloque o nome exato em
  `"arquivar_estes_nomes"` no `regras.json`, simule pra conferir e rode. Nunca use `marcas` pra isso
  (marca é arquivada mesmo com mensagem não lida). Nunca arquive "revisar" sem o ok.

## Regras de uso que você explica
- Uma janela por vez: enquanto o robô roda, ela não mexe naquela janela. Pra mexer na mão, use
  `node organizar-whatsapp.js abrir` (atalho `4-ABRIR`) e feche a janela quando terminar.
- Pra pausar tudo: criar um arquivo `PAUSADO.txt` dentro de `robo/`.
- Conversa arquivada volta pra tela quando chega mensagem nova SÓ se a opção "Manter conversas
  arquivadas" estiver DESLIGADA (no celular: Configurações > Conversas). Se estiver ligada, a
  conversa fica arquivada mesmo com mensagem nova, e ela pode não ver. Peça pra ela conferir essa
  opção antes de rodar e explique a diferença.
- Rodar todo dia sozinho (tarefa agendada) é possível, mas só depois de ela ter rodado algumas vezes
  com você, confiar no resultado e ter resolvido como os grupos de trabalho novos ficam protegidos.
  Ofereça, não faça por conta. Rotina agendada só roda com o app aberto e o computador acordado, e
  na primeira vez precisa rodar na mão ("Run now") e escolher "sempre permitir" em cada pedido,
  senão ela fica parada esperando aprovação.

## No fim: aprenda (com TRAVA)
Pergunte se acertou. Uma correção de um caso vira OBSERVAÇÃO no `memoria-whatsapp.md`. Só vira
regra no `regras.json` quando ela confirmar ou quando o padrão repetir.
