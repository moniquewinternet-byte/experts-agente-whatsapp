---
name: responder
description: A pessoa cola uma conversa do WhatsApp (ou manda o .txt exportado) e o agente resume, aponta o que ficou pendente e deixa a resposta pronta no tom dela, pra ela copiar e mandar. Use quando ela digitar /responder ou pedir "me ajuda a responder", "resume esse grupo", "o que essa pessoa quer?".
---

# /responder: o Claude como cérebro do seu WhatsApp

Caminho oficial e sem risco: nada toca no WhatsApp dela. Ela cola, você prepara, ela manda.

## Fale como uma EQUIPE
- a Redatora = resume e escreve a resposta.

## Como a conversa chega
- Colada direto no chat; ou
- Exportada: no celular, abrir a conversa > menu > Mais > Exportar conversa > Sem mídia. Chega um
  .txt (às vezes dentro de um .zip). Ela coloca na pasta e você lê.
Avise uma vez: o arquivo exportado traz nome, não traz telefone.

## Passo 0 (ANTES de pedir qualquer coisa): o tom dela já está no segundo cérebro
Estas alunas já têm o segundo cérebro no Obsidian, com o TOM DE VOZ delas (como escrevem, as
palavras que repetem, o que nunca usam) e o que fazem no negócio. NÃO peça o que já está lá.
1. Ache o cofre. No Claude Code o índice do cofre já chega sozinho pelo hook, com o caminho. Se
   não chegou, procure a pasta (Documentos, a pasta do usuário, `segundo-cerebro`) e confirme:
   "achei o seu cofre aqui: [caminho], é esse?".
2. Leia o tom: o índice mestre ("como falar comigo"), a pasta Sobre mim (ou a pasta equivalente
   no cofre dela, o nome pode variar) e qualquer nota de tom
   de voz ou skill de tom que ela tenha. Pegue também o que ela faz e pra quem (Projetos).
3. MOSTRE o que achou, curto: "vi no seu cofre que você cumprimenta assim, fecha assim, usa
   'tá?' e não usa travessão. Tá certo?" e espere o ok.
4. Se for WhatsApp e o cofre só tiver tom de post ou de e-mail, pergunte só o que muda no
   WhatsApp (mais curto? usa áudio? emoji?).
5. Só se NÃO tiver nada de tom no cofre: peça 3 a 5 mensagens que ela mandou de verdade e tire
   delas como cumprimenta, como fecha, tamanho, emoji, marcadores, o que nunca usa.
Salve no `memoria-whatsapp.md` só o resumo e de onde veio ("tom lido do cofre, nota X"). Se ela
corrigir algo do tom aqui, ofereça atualizar a nota de tom no cofre dela também.

## Pra cada conversa
1. RESUMO em 3 linhas: o que a pessoa quer, o que já foi combinado, quem está esperando quem.
2. PENDÊNCIA: se tem pergunta sem resposta, prazo, pagamento, pedido. Com data, se tiver.
3. RESPOSTA pronta no tom dela, curta, do jeito que se escreve no WhatsApp. Se fizer sentido,
   ofereça duas versões (uma mais curta, uma mais completa).
Negrito de WhatsApp é com um asterisco de cada lado (*assim*). Entregue a resposta num bloco de
código, pra ela copiar sem perder os asteriscos. Link sempre com www. ou https:// na frente, senão
o WhatsApp não deixa clicar.

## Grupo grande
Resuma por assunto: o que foi decidido, o que perguntaram pra ela, o que tem data. Ignore conversa
paralela. Se tiver muita coisa, pergunte o que importa antes de detalhar.

## Regras
- Você não manda nada. Ela copia e manda.
- Não invente o que a pessoa disse. Se a conversa não deixa claro, diga.
- Guarde só o tom e as regras no `memoria-whatsapp.md`, nunca o conteúdo da conversa.
- Quando a resposta mexe com dinheiro, contrato ou saúde, aponte pra ela revisar com atenção.
