/**
 * Robô de organizar o WhatsApp Web
 * Baseado no robô que a Monique usa no WhatsApp dela.
 * -------------------------------------------------------
 *   node organizar-whatsapp.js login    -> abre o WhatsApp Web pra você escanear o QR uma vez
 *   node organizar-whatsapp.js simular  -> NÃO arquiva nada; só lista o que faria
 *   node organizar-whatsapp.js rodar    -> arquiva de verdade, com ritmo de gente
 *   node organizar-whatsapp.js abrir    -> abre a janela já logada e deixa aberta pra você mexer
 *
 * As regras ficam no arquivo regras.json (o agente monta com você).
 *
 * O robô SÓ ARQUIVA (e arquivar é reversível).
 * NUNCA apaga, NUNCA manda mensagem, NUNCA sai de grupo, NUNCA muda configuração.
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const PASTA = __dirname;
const PERFIL = path.join(PASTA, 'perfil');
const LOGS = path.join(PASTA, 'logs');
const modo = (process.argv[2] || 'simular').toLowerCase();
const SIMULAR = modo === 'simular';

// ---------- trava: se existir PAUSADO.txt, o robô não roda
if (fs.existsSync(path.join(PASTA, 'PAUSADO.txt'))) {
  console.log('Robô pausado: existe um arquivo PAUSADO.txt nesta pasta. Apague ele pra voltar a rodar.');
  process.exit(0);
}

// ---------- regras
const ARQ_REGRAS = path.join(PASTA, 'regras.json');
if (!fs.existsSync(ARQ_REGRAS)) {
  console.log('Não achei o regras.json. Peça pro agente montar as suas regras primeiro (/organizar).');
  process.exit(1);
}
const R = JSON.parse(fs.readFileSync(ARQ_REGRAS, 'utf8'));
const norm = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
const PROTEGIDOS = (R.protegidos || []).map(norm);
const PROTEGIDOS_COMECO = (R.protegidos_que_comecam_com || []).map(norm);
const MARCAS = (R.marcas || []).map(norm);
const ARQ = Object.assign({
  grupos: true,            // arquiva grupos (menos os protegidos)
  eu_mandei_por_ultimo: 'revisar', // true = arquiva | 'revisar' = só lista pra você decidir | false = ignora
  reagidas: true,          // a última coisa foi uma reação
  marcas: true,            // empresas da lista "marcas"
  spam_de_numero: true,    // código, pedido, entrega, fatura... vindo de número sem nome salvo
}, R.arquivar || {});
const LIMITE = Number(R.limite_por_rodada || 0) || Infinity; // 0 = sem limite

// ---------- ritmo de gente (pausa entre ações + pausa longa de vez em quando)
const lento = R.ritmo === 'cauteloso';
const PAUSA = () => lento ? 15000 + Math.random() * 20000 : 4000 + Math.random() * 5000;
const PAUSA_LONGA = () => lento ? 90000 + Math.random() * 90000 : 20000 + Math.random() * 20000;
const PROXIMO_DESCANSO = () => lento ? 3 + Math.floor(Math.random() * 2) : 5 + Math.floor(Math.random() * 4);
let desdeDescanso = 0, limiteDescanso = PROXIMO_DESCANSO(), feitas = 0, PARAR = false;

// ---------- log
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const agora = () => new Date().toLocaleString('sv-SE', { timeZone: R.fuso || 'America/Sao_Paulo' });
const linhas = [];
const log = (m) => { const l = `[${agora()}] ${m}`; console.log(l); linhas.push(l); };
function salvarLog() {
  if (!fs.existsSync(LOGS)) fs.mkdirSync(LOGS, { recursive: true });
  const arq = path.join(LOGS, `${modo}-${agora().replace(/[: ]/g, '-')}.txt`);
  fs.writeFileSync(arq, linhas.join('\n'), 'utf8');
  console.log('\nLog salvo em: ' + arq);
}
const cont = { grupos: 0, eu_mandei: 0, reagidas: 0, marcas: 0, spam: 0, protegidos: 0, revisar: 0, falhas: 0 };
const paraRevisar = [];
const vistos = new Set();

// ---------- decisões
function ehProtegido(nome, fixada) {
  const n = norm(nome);
  if (fixada) return 'fixada';
  if (PROTEGIDOS_COMECO.some((p) => p && n.startsWith(p))) return 'protegido';
  if (PROTEGIDOS.some((p) => p && n.includes(p))) return 'protegido';
  return null;
}
const ehMarca = (nome) => MARCAS.some((m) => m && norm(nome).includes(m));
const pareceNumero = (nome) => /^\+?[\d\s().\-]{6,}$/.test((nome || '').trim());

// devolve { acao: 'arquivar' | 'revisar' | null, motivo }
function decidir(d) {
  if (ARQ.marcas && ehMarca(d.nome)) return { acao: 'arquivar', motivo: 'marca' };
  if (ARQ.spam_de_numero && d.spam && pareceNumero(d.nome)) return { acao: 'arquivar', motivo: 'spam de número' };
  if (d.naoLida) return { acao: null }; // alguém escreveu e você ainda não leu: fica na tela
  if (ARQ.reagidas && d.reagida) return { acao: 'arquivar', motivo: 'reação por último' };
  if (d.minhaUltima && ARQ.eu_mandei_por_ultimo) {
    return ARQ.eu_mandei_por_ultimo === true
      ? { acao: 'arquivar', motivo: 'você mandou por último' }
      : { acao: 'revisar', motivo: 'você mandou por último (pode estar esperando resposta)' };
  }
  return { acao: null };
}

// ---------- leitura da lista do WhatsApp Web
async function lerLinha(row) {
  return row.evaluate((el) => {
    const ne = el.querySelector('span[title]');
    const nome = ne ? (ne.getAttribute('title') || ne.textContent) : '';
    const titles = [...el.querySelectorAll('svg title')].map((t) => t.textContent || '');
    const txt = el.innerText || '';
    return {
      nome: (nome || '').trim(),
      fixada: titles.some((t) => /push-pin/i.test(t)),
      minhaUltima: titles.some((t) => /wds-ic-(read|dlvd|check)/i.test(t)),
      naoLida: /\bn[ãa]o lida/i.test(txt) || !!el.querySelector('[aria-label*="não lida"], [aria-label*="nao lida"]'),
      reagida: /reagiu com/i.test(txt),
      spam: /senha|c[oó]digo de (verifica|acesso|seguran)|c[oó]digo:? \d|seu pedido|pedido (foi|confirmad|a caminho|realizado)|rastre|sua entrega|saiu para entrega|foi entregue|nota fiscal|sua fatura|fatura (dispon|venc|fechad)|segunda via|sua assinatura/i.test(txt),
    };
  });
}
async function rolar(page) {
  return page.locator('#pane-side').evaluate((el) => { const a = el.scrollTop; el.scrollBy(0, 600); return el.scrollTop !== a; }).catch(() => false);
}
async function clicarFiltro(page, texto) {
  try {
    await page.locator('button, [role="tab"], [role="button"]').filter({ hasText: new RegExp('^' + texto) }).first().click({ timeout: 5000 });
    await sleep(1500);
    return true;
  } catch { log(`   (não achei o filtro "${texto}")`); return false; }
}
// espera a lista aparecer: 'ok' (logada), 'qr' (precisa logar) ou 'timeout' (só demorou)
async function esperarLista(page) {
  for (let tentativa = 1; tentativa <= 4; tentativa++) {
    for (let i = 0; i < 60; i++) {
      if (await page.locator('#pane-side').count().catch(() => 0)) return 'ok';
      if (await page.locator('canvas[aria-label*="scan" i], div[data-ref], canvas[role="img"]').count().catch(() => 0)) return 'qr';
      await sleep(3000);
    }
    log(`   (a lista não apareceu na tentativa ${tentativa}; recarregando...)`);
    await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
    await sleep(4000);
  }
  return 'timeout';
}
// espera o WhatsApp terminar de baixar as mensagens (senão o robô lê errado)
async function aguardarCarregar(page) {
  log('Esperando o WhatsApp carregar as mensagens...');
  let ok = 0;
  for (let i = 0; i < 60; i++) {
    await sleep(5000);
    const carregando = await page.locator('#pane-side [role="row"]')
      .evaluateAll((els) => els.filter((e) => /carregando/i.test(e.innerText || '')).length).catch(() => 9);
    if (i >= 5 && carregando <= 1) { if (++ok >= 2) { log('   ✓ carregou'); return; } } else ok = 0;
  }
  log('   (passou do tempo de espera, sigo assim mesmo)');
}

async function arquivar(page, row, nome, motivo) {
  if (SIMULAR) {
    if (vistos.has('s' + nome)) return false;
    vistos.add('s' + nome);
    log(`   [SIMULAR] arquivaria: ${nome}  (${motivo})`);
    return true;
  }
  try {
    await row.scrollIntoViewIfNeeded();
    await sleep(500 + Math.random() * 900);
    await row.hover().catch(() => {});
    await sleep(300 + Math.random() * 500);
    await row.click({ button: 'right' });
    await sleep(400 + Math.random() * 500);
    await page.getByText('Arquivar conversa', { exact: true }).first().click({ timeout: 4000 });
    log(`   ✓ ${nome}  (${motivo})`);
    if (++feitas >= LIMITE) { PARAR = true; log(`   ⏸ chegou no limite de ${LIMITE} por rodada. O resto fica pra próxima.`); return true; }
    await sleep(PAUSA());
    if (++desdeDescanso >= limiteDescanso) {
      const p = PAUSA_LONGA();
      log(`   … pausa de ${Math.round(p / 1000)}s`);
      await sleep(p);
      desdeDescanso = 0; limiteDescanso = PROXIMO_DESCANSO();
    }
    return true;
  } catch (e) {
    cont.falhas++;
    log(`   ⚠ não consegui arquivar "${nome}": ${e.message.split('\n')[0]} (arquive na mão, é rápido pela busca)`);
    await page.keyboard.press('Escape').catch(() => {});
    return false;
  }
}

// passa pela lista do filtro atual aplicando a regra
async function varrer(page, rotulo, regra) {
  log(`=== ${rotulo} ===`);
  await page.locator('#pane-side').evaluate((el) => { el.scrollTop = 0; }).catch(() => {});
  await sleep(600);
  const feitosAqui = new Map();
  let semMudar = 0;
  for (let i = 0; i < 300 && !PARAR; i++) {
    const rows = await page.locator('#pane-side [role="row"]').all();
    let agiu = false;
    for (const r of rows) {
      let d; try { d = await lerLinha(r); } catch { continue; }
      if (!d.nome) continue;
      const prot = ehProtegido(d.nome, d.fixada);
      if (prot) { if (!vistos.has('p' + d.nome)) { vistos.add('p' + d.nome); cont.protegidos++; log(`   🔒 ${d.nome} (${prot})`); } continue; }
      if ((feitosAqui.get(d.nome) || 0) >= 2) continue; // grupo muito ativo volta pro topo: no máximo 2x por rodada
      const dec = regra(d);
      if (!dec.acao) continue;
      if (dec.acao === 'revisar') {
        if (!vistos.has('r' + d.nome)) { vistos.add('r' + d.nome); cont.revisar++; paraRevisar.push(d.nome); log(`   👀 revisar: ${d.nome}  (${dec.motivo})`); }
        continue;
      }
      const ok = await arquivar(page, r, d.nome, dec.motivo);
      if (ok) {
        if (dec.motivo === 'grupo') cont.grupos++;
        else if (dec.motivo === 'marca') cont.marcas++;
        else if (dec.motivo === 'spam de número') cont.spam++;
        else if (dec.motivo === 'reação por último') cont.reagidas++;
        else cont.eu_mandei++;
        if (!SIMULAR) { feitosAqui.set(d.nome, (feitosAqui.get(d.nome) || 0) + 1); agiu = true; break; }
      }
    }
    if (agiu) { semMudar = 0; continue; }
    if (!(await rolar(page))) { if (++semMudar >= 3) break; } else semMudar = 0;
  }
}

// abre o navegador: Edge no Windows, Chrome no Mac; se não der, o Chromium do Playwright
async function abrirNavegador() {
  const tentativas = process.platform === 'win32' ? ['msedge', 'chrome', undefined]
    : process.platform === 'darwin' ? ['chrome', undefined] : [undefined, 'chrome'];
  let ultimoErro;
  for (const channel of tentativas) {
    try {
      const ctx = await chromium.launchPersistentContext(PERFIL, {
        headless: false, channel, chromiumSandbox: true, viewport: { width: 1280, height: 900 },
      });
      log(`(navegador: ${channel || 'chromium do playwright'})`);
      return ctx;
    } catch (e) { ultimoErro = e; }
  }
  throw ultimoErro;
}

let ctx = null;
(async () => {
  log(`### Robô de organizar o WhatsApp, modo: ${modo.toUpperCase()} ###`);
  ctx = await abrirNavegador();
  const page = ctx.pages()[0] || (await ctx.newPage());
  await page.goto('https://web.whatsapp.com', { waitUntil: 'domcontentloaded' });

  if (modo === 'login') {
    log('Escaneie o QR com o celular (WhatsApp > Aparelhos conectados). Espero até 5 minutos...');
    try { await page.waitForSelector('#pane-side', { timeout: 300000 }); log('✅ Login salvo. Da próxima vez não pede QR.'); }
    catch { log('⚠ Não vi o login acontecer. Rode o login de novo.'); }
    await sleep(2500); await ctx.close(); salvarLog(); return;
  }

  if (modo === 'abrir') {
    log('Janela aberta e logada. Mexa à vontade. Quando terminar, feche a janela.');
    log('Enquanto ela estiver aberta, não rode outro modo do robô.');
    await new Promise((resolve) => ctx.on('close', resolve));
    salvarLog(); return;
  }

  const estado = await esperarLista(page);
  if (estado === 'qr') { log('⚠ Não está logada (apareceu o QR). Rode o login primeiro.'); await ctx.close(); salvarLog(); return; }
  if (estado === 'timeout') { log('⚠ A lista demorou demais pra carregar. Não mexi em nada. Tenta de novo daqui a pouco.'); await ctx.close(); salvarLog(); return; }
  await sleep(3000);
  try { const c = page.getByRole('button', { name: 'Continuar' }); if (await c.count()) await c.first().click(); } catch {}
  await aguardarCarregar(page);

  for (let rodada = 1; rodada <= 3 && !PARAR; rodada++) {
    const antes = cont.grupos + cont.eu_mandei + cont.reagidas + cont.marcas + cont.spam;
    if (ARQ.grupos) {
      await clicarFiltro(page, 'Grupos');
      await varrer(page, `GRUPOS (rodada ${rodada})`, () => ({ acao: 'arquivar', motivo: 'grupo' }));
      await clicarFiltro(page, 'Tudo');
    }
    if (!PARAR) await varrer(page, `CONVERSAS (rodada ${rodada})`, decidir);
    const naRodada = cont.grupos + cont.eu_mandei + cont.reagidas + cont.marcas + cont.spam - antes;
    log(`   >> rodada ${rodada}: ${naRodada}`);
    if (SIMULAR || naRodada === 0) break; // simular passa uma vez só
  }

  log('==================== RESUMO ====================');
  log(`Grupos: ${cont.grupos} | Você mandou por último: ${cont.eu_mandei} | Reações: ${cont.reagidas}`);
  log(`Marcas: ${cont.marcas} | Spam de número: ${cont.spam} | Protegidas: ${cont.protegidos} | Falhas: ${cont.falhas}`);
  if (paraRevisar.length) log(`Pra você revisar (${paraRevisar.length}): ${paraRevisar.join(' | ')}`);
  if (SIMULAR) log('>> SIMULAÇÃO: nada foi arquivado. <<');
  log('================================================');
  await sleep(1500); await ctx.close(); salvarLog();
})().catch(async (e) => {
  log('ERRO: ' + e.message);
  if (ctx) await ctx.close().catch(() => {}); // fecha a janela pra não travar o perfil
  salvarLog(); process.exit(1);
});
