@echo off
cd /d "%~dp0"
node organizar-whatsapp.js simular
pause
