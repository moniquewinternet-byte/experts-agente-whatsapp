# Os caminhos de automação do WhatsApp

Conferido em novembro de 2026. Use estes números como base, dizendo a data. Preço e regra da Meta
mudam: se você tiver busca na web, confira na página oficial antes de fazer um orçamento
(developers.facebook.com, "Pricing on the WhatsApp Business Platform").

## Antes de tudo: o que é API
- API: o jeito de um programa conversar com outro programa, sem ninguém clicar na tela.
- API oficial do WhatsApp: o acesso que a própria Meta libera pra empresas mandarem e receberem
  mensagens por programa. Tem cadastro da empresa, um número só pro negócio, regras e cobrança
  por mensagem. Não bloqueia o número.
- Não-oficial: um programa que entra no WhatsApp Web com o seu número, como se fosse você no
  navegador. É barato e faz mais coisa, e pode bloquear o número, porque a Meta não autoriza.

## Palavras que aparecem
- Aparelho conectado: cada lugar onde o WhatsApp está logado (Web, computador, um robô).
- QR code: como se conecta um aparelho novo, escaneando com o celular.
- n8n: ferramenta que liga um app no outro ("quando acontecer isso, faça aquilo").
- Playwright: programa que controla um navegador sozinho.
- Conector (MCP): o jeito de ligar um app no Claude.
- Plataforma: empresa já ligada na API oficial que dá a tela pronta (ManyChat, Blip, Zenvia).
- Janela de 24 horas: depois que o cliente chama, 24 horas pra responder com mensagem livre.
- Mensagem aprovada (modelo): fora das 24 horas, só mensagem que a Meta aprovou antes.

## Os 7 caminhos, em três vontades

### Atender cliente sem você estar lá

**01. O que já vem no WhatsApp Business (oficial, grátis)**
Saudação, ausência, respostas rápidas ("/"), etiquetas, catálogo. E o Business AI, agente de IA
da Meta dentro do app, que responde o cliente com base no que você contou do negócio e passa pra
você quando precisa. Chegou ao Brasil em 2026, liberando aos poucos, de graça (em Ferramentas).
Risco: nenhum. Limite: não conversa com CRM, planilha ou Claude.

**02. API oficial da Meta (oficial)**
Cadastro da empresa na Meta + número só pro negócio + uma plataforma (ManyChat, Blip, Zenvia,
Twilio) ou direto pela Meta. Integra com checkout, CRM e IA.
Custo no Brasil, em reais, desde 01/10/2026 (tabela da Meta):
- marketing: R$0,3217 por mensagem (a mais cara);
- utilidade (pedido, lembrete, pagamento) e autenticação: R$0,0350 por mensagem;
- atendimento (responder quem te chamou): as 1.000 primeiras do mês, por número, são grátis.
  Depois, R$0,0350 cada.
- mais a mensalidade da plataforma (ex.: ManyChat Pro a partir de US$29/mês, cobrado em dólar).
Exemplo de confirmação diária: 12 lembretes por dia útil (uns 264 no mês) = uns R$9,24 por mês,
mais a plataforma.
Exemplos de conta: 500 lembretes de Pix = R$17,50; 2.000 respostas pra clientes = R$35;
1.000 mensagens de promoção = R$321,70.
Regras: a pessoa aceitou receber; fora das 24 horas, só mensagem aprovada. Desde jan/2026 a Meta
não deixa oferecer assistente de IA genérico pela API; IA atendendo o cliente do seu negócio
continua permitida. Não gerencia grupo.

**03. API não-oficial (não-oficial)**
Evolution API, uazapi, Z-API, WPPConnect, Baileys. Conecta o número por QR num serviço que fica
num servidor (um WhatsApp Web aberto o tempo todo). Com o n8n vira chatbot, disparo, lembrete,
CRM, gestão de grupo. Muita ferramenta de mercado usa isso por baixo nos planos mais baratos.
Custo: Evolution API é grátis (código aberto) + servidor de US$6 a US$26/mês; hospedada, a
partir de R$35 por número por mês.
Risco: alto. A Meta não autoriza, pode bloquear o número, e as conversas passam pelo servidor.

### Responder melhor, com você no comando

**04. O Claude como cérebro, você cola (oficial, risco zero)**
(Em lote, é a `/mensagens`: o Claude prepara várias mensagens e uma pessoa clica e envia cada uma.)
Copia a conversa (ou exporta o .txt) e cola no Claude: resumo, pendência e resposta no seu tom.
Você revisa e manda. Custo: o plano do Claude. O exportado traz nome, não telefone.
É a `/responder` deste agente.

**05. O Claude com acesso direto ao seu WhatsApp (conector MCP, não-oficial)**
Instala um conector no Claude e liga o número por QR. Na conversa com o Claude você pergunta
("o que a Bia me pediu em setembro?") e ele procura no seu WhatsApp.
Diferente do 03: no 03 um robô atende sozinho o dia todo; aqui o Claude só mexe quando você pede.
Custo: o que roda no seu computador é grátis; hospedados cobram. Risco: usa a mesma conexão
não-oficial do 03. Não existe conector oficial da Anthropic. Ler o código antes de dar acesso.

### Organizar o seu WhatsApp

**06. O Claude no Chrome lendo o WhatsApp Web (não-oficial)**
Abre o WhatsApp Web no Chrome e pede pra extensão do Claude ler a tela. Custo: plano do Claude.
Risco: IA mexendo no WhatsApp Web; o WhatsApp testa aviso pra extensões. Uso pra ler, com calma.

**07. O robô que organiza (Playwright, não-oficial)**
Programa abre o WhatsApp Web no seu computador e arquiva grupo, conversa resolvida e propaganda,
com pausa de gente. Grátis. Só arquiva (reversível), anda devagar e simula antes.
Limite: computador ligado; grupo muito ativo volta pra tela. É a `/organizar` deste agente.

## Tabela rápida
| Caminho | Oficial? | Risco pro número | Custo |
|---|---|---|---|
| 01. WhatsApp Business | sim | nenhum | grátis |
| 02. API oficial | sim | nenhum | R$0,035 a R$0,32 por mensagem + plataforma |
| 03. API não-oficial | não | alto | servidor US$6 a 26/mês, ou R$35/número |
| 04. Claude, você cola | sim | nenhum | plano do Claude |
| 05. Claude com acesso ao WhatsApp | não | médio a alto | grátis no seu computador |
| 06. Claude no Chrome | não | baixo | plano do Claude |
| 07. Robô que organiza | não | controlado | grátis |

## Como escolher (pelo objetivo)
A pergunta antes de tudo: se esse número ficasse parado uns dias, o quanto isso te atrapalha?
Quanto mais importa, mais oficial e mais número separado.
- Parar de responder a mesma coisa: 01.
- Vender e cobrar em volume: 02.
- Grupo grande: 03, em número separado.
- Responder melhor e mais rápido: 04 (a `/responder`).
- Mandar várias mensagens parecidas (confirmação, lembrete, cobrança), com alguém clicando: 04 em
  lote (a `/mensagens`). Sem ninguém clicar: 02.
- Ver o Claude no WhatsApp: 05, em número separado.
- Achar uma conversa antiga: 06 ou 04.
- WhatsApp bagunçado: 07 (a `/organizar`).
- "Vi um tutorial de disparo em massa no número pessoal": não. Número separado e caminho 02.
