# Os caminhos de automação do WhatsApp

Conferido em novembro de 2026. Preço e regra da Meta mudam: antes de afirmar número, confira no
site oficial (developers.facebook.com, página "Pricing on the WhatsApp Business Platform").

Uma ideia organiza tudo: existem caminhos OFICIAIS (feitos ou aprovados pela Meta) e caminhos
NÃO-OFICIAIS (um programa se passa por você no WhatsApp Web ou no app). O oficial tem regra e às
vezes custo, e não bloqueia o número. O não-oficial é barato e faz mais coisa, e pode bloquear o
número, porque os termos do WhatsApp não permitem automação que ele não autorizou.

---

## 1. O que já vem no WhatsApp Business (oficial, grátis)
O app WhatsApp Business, o verde com o "B", já traz automação pronta:
- mensagem de saudação (quem fala com você pela primeira vez);
- mensagem de ausência (fora do horário);
- respostas rápidas (atalho com "/" pra texto que você repete);
- etiquetas (novo cliente, pago, aguardando) e catálogo.
- Business AI: um agente de IA da própria Meta, dentro do app, que responde cliente, sugere produto
  do catálogo e passa pra você quando precisa. Chegou ao Brasil em 2026, liberando aos poucos, de
  graça. Fica em Ferramentas, no app.

Benefício: zero risco, zero custo, liga em minutos.
Limite: é do jeito da Meta. Não conversa com seu CRM, sua planilha ou o Claude.
Serve pra: quem atende cliente e ainda responde tudo na mão.

## 2. O Claude como cérebro, você no comando (oficial, risco zero)
Você copia a conversa (ou usa Exportar conversa > .txt) e cola no Claude. Ele resume, acha o que
ficou pendente e escreve a resposta no seu tom. Você revisa e manda.

Benefício: risco zero, porque nada toca no seu WhatsApp. Funciona hoje, em qualquer plano.
Limite: é manual. O arquivo exportado não traz o telefone das pessoas, só o nome.
Serve pra: responder melhor e mais rápido, follow-up, resumir grupo grande.

## 3. O Claude no Chrome, olhando o WhatsApp Web que você abriu
Você abre o WhatsApp Web no seu navegador e pede pro Claude (extensão do Chrome) ler, resumir ou
procurar alguma coisa na tela.

Benefício: lê muita conversa sem você copiar uma por uma.
Risco: é uma IA mexendo no WhatsApp Web, então entra na zona do não-oficial. O WhatsApp está
testando um aviso pra quem usa extensão ou cliente que não é dele. Use pra ler, com calma.
Serve pra: recuperar contexto de cliente, achar uma conversa antiga, levantar pendências.

## 4. Robô no WhatsApp Web (Playwright): o robô de organizar
Um programa abre o WhatsApp Web (você loga pelo QR, igual faz no navegador) e clica sozinho:
arquiva grupo, arquiva conversa resolvida, tira propaganda da frente. É o que a Monique usa.

Benefício: o WhatsApp fica limpo sem você gastar tempo arquivando. Grátis.
Risco: é não-oficial e roda no seu número. Por isso ele SÓ arquiva (arquivar se desfaz), anda em
ritmo de gente e simula antes de agir.
Limite: só funciona com o computador ligado. Grupo muito ativo volta pra tela quando chega
mensagem nova (isso é do WhatsApp).
Serve pra: organizar o seu próprio WhatsApp. Não serve pra mandar mensagem nem pra volume.

## 5. Número conectado por API não-oficial (Evolution API, uazapi, Z-API, WPPConnect, Baileys)
É o que mais aparece em curso e no YouTube. Você conecta o número por QR num serviço, ele vira uma
API e, quase sempre com o n8n, você monta chatbot, disparo, lembrete, integração com CRM e gestão
de grupo. Muitas ferramentas de mercado usam isso por baixo nos planos mais baratos (a Voxuy, por
exemplo, só tem API oficial no plano Enterprise).

Benefício: barato, manda mensagem a qualquer hora, manda áudio, mexe em grupo, tudo sem aprovação.
Risco: é engenharia reversa do WhatsApp. Pode bloquear o número, e as próprias bibliotecas avisam
isso. As suas conversas passam por um servidor (seu ou de terceiro).
Serve pra: quem aceita o risco num número separado, ou pra gestão de grupo (que o oficial não faz).

## 6. API oficial da Meta (WhatsApp Business Platform / Cloud API)
O caminho aprovado. Usa um número só pra isso, ligado por uma plataforma (ManyChat, Blip, Twilio,
360dialog, Zenvia e outras) ou direto pela Meta.

Como cobra (desde julho de 2025, por mensagem):
- quando o cliente te chama, abre uma janela de 24 horas. Responder dentro dela é grátis;
- fora da janela, só com modelo de mensagem aprovado pela Meta, e cada um é cobrado. Modelo de
  utilidade (pedido, lembrete, pagamento) é barato e é grátis dentro da janela. Modelo de
  marketing é o mais caro.
- a plataforma costuma cobrar a mensalidade dela por cima.
Regras: a pessoa precisa ter aceitado receber. Desde janeiro de 2026 a Meta não deixa usar a API pra
oferecer um assistente de IA genérico (tipo ChatGPT no WhatsApp). Usar IA pra atender o cliente do
SEU negócio continua permitido.

Benefício: não bloqueia o número, aguenta volume, integra com checkout, CRM e IA.
Limite: não gerencia grupo, precisa de modelo aprovado pra puxar conversa, tem custo por mensagem.
Serve pra: negócio que atende, recupera venda, lembra pagamento, em escala.

## 7. Conectar o WhatsApp direto no Claude (conector MCP)
Já existem conectores que ligam o WhatsApp no Claude: uns rodam no seu computador (guardam as
mensagens num banco seu), outros são serviços hospedados (GREEN-API, Evolution, uazapi). Com isso o
Claude lê, procura e até manda mensagem de dentro da conversa.

Benefício: o Claude vira a inteligência em cima do seu WhatsApp inteiro.
Risco: quase todos usam por baixo o mesmo caminho não-oficial do item 5 (o principal da GREEN-API,
por exemplo, conecta como aparelho, igual o WhatsApp Web). Ainda não existe conector oficial da
Anthropic pro WhatsApp. Leia o código antes de dar acesso, e o local só roda com o Claude aberto.
Serve pra: quem quer aprender e testar, de preferência num número que não é o principal.

---

## Tabela rápida
| Caminho | Oficial? | Risco pro número | Custo | Serve pra |
|---|---|---|---|---|
| 1. WhatsApp Business nativo | sim | nenhum | grátis | saudação, ausência, IA da Meta |
| 2. Claude, você cola | sim | nenhum | o plano do Claude | resumir, responder no seu tom |
| 3. Claude no Chrome | não | baixo, só leitura | o plano do Claude | achar e resumir conversa |
| 4. Robô de organizar | não | existe, controlado | grátis | arquivar e limpar |
| 5. API não-oficial + n8n | não | alto | baixo | chatbot, disparo, grupos |
| 6. API oficial | sim | nenhum | por mensagem + plataforma | atender e vender em escala |
| 7. Conector MCP no Claude | quase sempre não | médio a alto | varia | testar Claude + WhatsApp |

## Como escolher (pelo objetivo)
- "Quero parar de responder a mesma coisa": 1 (respostas rápidas, ausência, Business AI).
- "Quero responder melhor e mais rápido": 2, e a `/responder` deste agente.
- "Meu WhatsApp é uma bagunça": 4, a `/organizar` deste agente.
- "Quero achar o que um cliente me falou meses atrás": 3 ou 2.
- "Quero recuperar venda, lembrar pagamento, atender em volume": 6.
- "Quero gerenciar grupo grande": 5, num número separado, sabendo do risco.
- "Quero ver o Claude mexendo no meu WhatsApp": 7, num número de teste.
- "Vi um tutorial de disparo em massa no número pessoal": não. Número separado e caminho 6.
